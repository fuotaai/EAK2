package pg8sj5;

import java.util.*;
import java.util.concurrent.*;

/** An immutable board of non-attacking queens. */
public class Board {

	/** An immutable linked list of int values. */
	protected static class Node {
		protected final int value;
		protected final Node next;
		protected Node( int value, Node next ){
			this.value = value;
			this.next = next;
		}
	}
        
        class AggregatorThread implements Runnable {
            
            private boolean done = false;

            @Override
            public void run() {
                listOfBoardLists.forEach(boardList -> result.addAll(boardList));
                done = true;
            }
            
            public boolean isDone() {
                return done;
            }
        }
        
        public class MyThread implements Runnable {
            
            private final int row;
            private final int size;
            private final Board board;
            
            public MyThread(int row, int size, Board board) {
                this.row = row;
                this.size = size;
                this.board = board;
            }
            
            @Override
            public void run() {
                listOfBoardLists.add(new Board(row, board).continuations(size));                                        
           
                try {
                    cyclicBarrier.await();
                } catch (InterruptedException | BrokenBarrierException e) {}
            }  
        }

	protected final Node queens;   // list of non-attacking queens
	protected final int nrQueens;  // length of queens
        
        protected static CyclicBarrier cyclicBarrier;
        protected List<List<Board>> listOfBoardLists
     = Collections.synchronizedList(new ArrayList<>());
        protected List<Board> result = new ArrayList<>();
        
        
	/** An empty board. */
	protected Board(){
		queens = null;
		nrQueens = 0;
	}

	/** Adding a new column to a board. */
	protected Board( int queen, Board board ){ 
		queens = new Node(queen,board.queens);
		nrQueens = board.nrQueens + 1;
	}

	/** Whether a new queen attacks existing queens on this board. */
	protected boolean attacks( int queen ){
		int distance = 0;
		Node cursor = queens;
		while( cursor != null ){
			++distance;
			if( queen == cursor.value || Math.abs(queen - cursor.value) == distance ){
				return true;
			}
			cursor = cursor.next;
		}
		return false;
	}

	/** Compute all possible solutions starting from the current board. */
	protected List<Board> continuations( int size ){
                if(queens == null) {
                    AggregatorThread aggregatorThread = new AggregatorThread();
                    cyclicBarrier = new CyclicBarrier(size, aggregatorThread);
                    for( int row = 1; row <= size; ++row ){
                        Thread thread = new Thread(new MyThread(row, size, this));
                        thread.start();
                    }
                    
                    while(!aggregatorThread.isDone()) {
                        System.out.println("");
                    }
                    return result;
                } else if( nrQueens == size ){ // no more queens have to be added
                    List<Board> result = new ArrayList<>();
                    result.add(this);
                    return  result;   // return a single solution: this
		} else {
			// add one more column by trying all non-attacking rows in that column,
			// and recursively find all continuations from all the resulting boards
			List<Board> boards = new LinkedList<>();
			for( int row = 1; row <= size; ++row ){
				if( !attacks(row) ){
					boards.addAll((new Board(row,this)).continuations(size));
				}
			}
			return boards;
		}
	}

	/** Place <code>size</code> queens on a size x size board in all possible ways. */
	public static List<Board> solve( int size ){
            return (new Board()).continuations(size);
	}
}

class NQueens {
	public static void main( String[] args ){
		System.out.println( Board.solve( Integer.parseInt(args[0]) ).size() );
	}
}


